import React, { useState } from 'react';
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { ArrowLeft, Info, CaretDown } from 'phosphor-react';
import svgPaths from "../imports/svg-m8h3zewox8";

interface DetalhesDoProductoFormProps {
  onBack: () => void;
  companyName: string;
  selectedPlan: string;
}

interface CompanyData {
  cnpj: string;
  razaoSocial: string;
  nomeFantasia: string;
  endereco: string;
  status: 'Ativo' | 'Inativo' | 'Suspensa';
}

// Dados mock do plano baseado na seleção
const getPlanData = (planId: string) => {
  const plans: Record<string, any> = {
    'direto-nacional-enfermaria': {
      title: 'Direto Nacional - SP (CA1)',
      subtitle: 'Enfermaria',
      features: ['553 - CBO - 12 meses', 'Sem coparticipação'],
      price: '2.742,69',
      details: {
        '0-18': { ageGroup: '0 a 18 anos', lives: [{ age: '1 ano', price: '294,74', count: 1 }, { age: '3 anos', price: '294,74', count: 1 }] },
        '29-33': { ageGroup: '29 a 33 anos', lives: [{ age: '29 anos', price: '944,23', count: 1 }] },
        '59-60+': { ageGroup: '59 a 60+ anos', lives: [{ age: '59 anos', price: '294,74', count: 1 }, { age: '60 anos', price: '294,74', count: 1 }, { age: '61 anos', price: '294,74', count: 1 }] }
      }
    },
    'direto-nacional-apartamento': {
      title: 'Direto Nacional - SP (CA1)',
      subtitle: 'Apartamento',
      features: ['553 - CBO - 12 meses', 'Sem coparticipação'],
      price: '3.742,69',
      details: {
        '0-18': { ageGroup: '0 a 18 anos', lives: [{ age: '1 ano', price: '394,74', count: 1 }, { age: '3 anos', price: '394,74', count: 1 }] },
        '29-33': { ageGroup: '29 a 33 anos', lives: [{ age: '29 anos', price: '1044,23', count: 1 }] },
        '59-60+': { ageGroup: '59 a 60+ anos', lives: [{ age: '59 anos', price: '394,74', count: 1 }, { age: '60 anos', price: '394,74', count: 1 }, { age: '61 anos', price: '394,74', count: 1 }] }
      }
    }
  };
  
  return plans[planId] || plans['direto-nacional-enfermaria'];
};

function BackIcon() {
  return (
    <ArrowLeft 
      size={20} 
      color="#F05223" 
      weight="bold"
    />
  );
}

function BackButton({ onClick }: { onClick: () => void }) {
  return (
    <Button
      onClick={onClick}
      variant="ghost"
      className="inline-flex items-center justify-center h-[48px] px-6 border border-gray-300 text-gray-700 rounded-full hover:bg-gray-50 hover:text-gray-900 transition-colors text-sm gap-2 font-['Aestetico:Medium',_sans-serif]"
    >
      <BackIcon />
      Voltar
    </Button>
  );
}

function CheckIcon() {
  return (
    <div className="relative shrink-0 size-4">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <path
          d={svgPaths.p991aa80}
          fill="var(--fill-0, black)"
        />
      </svg>
    </div>
  );
}

function PlanFeatures({ features }: { features: string[] }) {
  return (
    <div className="box-border content-stretch flex flex-col gap-2.5 items-start justify-start p-0 relative shrink-0 w-full">
      {features.map((feature, index) => (
        <div key={index} className="relative rounded-sm shrink-0 w-full">
          <div className="flex flex-row items-center justify-center relative size-full">
            <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-1 py-0 relative w-full">
              <CheckIcon />
              <div className="basis-0 font-['Lintel:Regular',_sans-serif] grow leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#000000] text-[14px] text-left">
                <p className="block leading-[21px]">{feature}</p>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function SimpleAccordion({ details }: { 
  details: Record<string, { ageGroup: string; lives: Array<{ age: string; price: string; count: number }> }>
}) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="w-full">
      <div className="border-none">
        <button
          type="button"
          className="font-['Lintel:Bold',_sans-serif] text-[#101213] text-[16px] leading-[24px] px-0 py-6 hover:no-underline flex flex-1 items-center justify-between w-full text-left"
          onClick={() => setIsOpen(!isOpen)}
        >
          Ver detalhes das vidas e valores
          <CaretDown 
            size={16} 
            color="#F05223" 
            className={`shrink-0 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
          />
        </button>
        
        {isOpen && (
          <div className="px-0 pb-4 overflow-hidden text-sm transition-all">
            <div className="pb-4 pt-0">
              <div className="space-y-6">
                {Object.entries(details).map(([key, ageGroupData]) => (
                  <div key={key} className="space-y-4">
                    {/* Age Group Header */}
                    <div className="font-['Lintel:Bold',_sans-serif] text-[#272b30] text-[16px] leading-[21px]">
                      {ageGroupData.ageGroup}
                    </div>
                    
                    {/* Lives in this age group */}
                    <div className="space-y-3">
                      {ageGroupData.lives.map((life, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex flex-col">
                            <div className="font-['Lintel:Bold',_sans-serif] text-[#272b30] text-[14px] leading-[21px]">
                              {life.age}
                            </div>
                            <div className="font-['Lintel:Regular',_sans-serif] text-[#272b30] text-[12px] leading-[18px]">
                              R$ {life.price.replace('.', ',')} por vida
                            </div>
                          </div>
                          <div className="font-['Lintel:Regular',_sans-serif] text-[#272b30] text-[14px] text-right">
                            <span className="font-['Lintel:Bold',_sans-serif] text-[#adb5bd]">
                              {life.count} x
                            </span>
                            {` R$ ${(parseFloat(life.price.replace(',', '.')) * life.count).toFixed(2).replace('.', ',')}`}
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    {/* Add separator between age groups except for the last one */}
                    {key !== Object.keys(details)[Object.keys(details).length - 1] && (
                      <div className="border-b border-[#e4e4e4] pt-2"></div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function PlanDetails({ title, subtitle, features, price, details }: {
  title: string;
  subtitle: string;
  features: string[];
  price: string;
  details: Record<string, { ageGroup: string; lives: Array<{ age: string; price: string; count: number }> }>;
}) {
  return (
    <div className="absolute bg-[#ffffff] box-border content-stretch flex flex-col gap-8 items-start justify-start left-[440px] px-0 py-6 rounded-xl top-[118px] w-[480px]">
      <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full">
        {/* Header */}
        <div className="relative shrink-0 w-full">
          <div className="relative size-full">
            <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start px-6 py-0 relative w-full">
              <div className="box-border content-stretch flex flex-row gap-16 items-start justify-start p-0 relative shrink-0 w-full">
                <div className="font-['Lintel:Bold',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#272b30] text-[26px] text-left text-nowrap">
                  <p className="block leading-[21px] whitespace-pre">
                    {title}
                  </p>
                </div>
              </div>
              <div className="font-['Lintel:Regular',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#6a7178] text-[14px] text-left w-full">
                <p className="block leading-[21px]">{subtitle}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Benefits */}
        <div className="relative shrink-0 w-full">
          <div className="overflow-clip relative size-full">
            <div className="box-border content-stretch flex flex-col gap-4 items-start justify-start px-6 py-0 relative w-full">
              <PlanFeatures features={features} />
              
              {/* Simple Accordion for Details */}
              <div className="mt-2">
                <SimpleAccordion details={details} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function CotacaoInfo({ companyName }: { companyName: string }) {
  const today = new Date();
  const todayStr = today.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-6 items-start justify-start left-[1000px] p-[24px] top-[118px] w-[483px]">
      {/* Dados da Cotação */}
      <div className="box-border content-stretch flex flex-col gap-4 items-start justify-start p-0 relative shrink-0 w-full">
        <div className="box-border content-stretch flex flex-row gap-2 items-start justify-start overflow-clip p-0 relative shrink-0 w-full">
          <div className="basis-0 box-border content-stretch flex flex-col gap-2 grow items-start justify-start leading-[0] min-h-px min-w-px not-italic p-0 relative shrink-0 text-[#272b30] text-left">
            <div className="font-['Lintel:Bold',_sans-serif] relative shrink-0 text-[28px] w-full">
              <p className="block leading-[21px]">Dados da Cotação</p>
            </div>
            <div className="font-['Lintel:Regular',_sans-serif] relative shrink-0 text-[14px] w-full">
              <p className="block leading-[21px]">
                Confirme as informações antes de prosseguir com a simulação
              </p>
            </div>
          </div>
        </div>

        {/* Data fields */}
        <div className="box-border content-stretch flex flex-row gap-4 items-start justify-start p-0 relative shrink-0 w-full">
          <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start leading-[0] not-italic p-0 relative shrink-0 text-[#272b30] text-left w-[125px]">
            <div className="flex flex-col font-['Lintel:Bold',_sans-serif] h-[17px] justify-center relative shrink-0 text-[16px] w-full">
              <p className="block leading-[21px]">Data da simulação</p>
            </div>
            <div className="font-['Lintel:Regular',_sans-serif] relative shrink-0 text-[14px] w-full">
              <p className="block leading-[21px]">{todayStr}</p>
            </div>
          </div>
          
          <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start leading-[0] not-italic p-0 relative shrink-0 text-[#272b30] text-left w-[82px]">
            <div className="flex flex-col font-['Lintel:Bold',_sans-serif] h-[17px] justify-center relative shrink-0 text-[16px] w-full">
              <p className="block leading-[21px]">Qtd. Vidas</p>
            </div>
            <div className="font-['Lintel:Regular',_sans-serif] relative shrink-0 text-[14px] text-nowrap">
              <p className="block leading-[21px] whitespace-pre">3</p>
            </div>
          </div>
        </div>
      </div>

      {/* Separator */}
      <div className="h-0 relative shrink-0 w-full">
        <div className="absolute bottom-0 left-0 right-0 top-[-1px]">
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 435 1"
          >
            <line
              stroke="var(--stroke-0, #CED4DA)"
              x2="435"
              y1="0.5"
              y2="0.5"
            />
          </svg>
        </div>
      </div>

      {/* Definição do Contrato */}
      <div className="box-border content-stretch flex flex-col gap-4 items-start justify-start p-0 relative shrink-0 w-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-[435px]">
          <div className="font-['Lintel:Bold',_sans-serif] leading-[0] min-w-full not-italic relative shrink-0 text-[#272b30] text-[28px] text-left">
            <p className="block leading-[21px]">Definição do Contrato</p>
          </div>
        </div>

        {/* Contract details */}
        <div className="space-y-4">
          <div className="flex flex-row gap-4">
            <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start leading-[0] not-italic p-0 relative shrink-0 text-[#272b30] text-left w-[125px]">
              <div className="flex flex-col font-['Lintel:Bold',_sans-serif] h-[17px] justify-center relative shrink-0 text-[16px] w-full">
                <p className="block leading-[21px]">Carteira</p>
              </div>
              <div className="font-['Lintel:Regular',_sans-serif] relative shrink-0 text-[14px] w-full">
                <p className="block leading-[21px]">PME</p>
              </div>
            </div>
            
            <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start leading-[0] not-italic p-0 relative self-stretch shrink-0 text-[#272b30] text-left">
              <div className="flex flex-col font-['Lintel:Bold',_sans-serif] h-[17px] justify-center relative shrink-0 text-[16px] w-full">
                <p className="block leading-[21px]">Produto</p>
              </div>
              <div className="font-['Lintel:Regular',_sans-serif] leading-[21px] relative shrink-0 text-[14px] w-full">
                <p className="block mb-0">557 - Ambulatorial e Hospitalar</p>
                <p className="block">com Obstetrícia</p>
              </div>
            </div>
            
            <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start leading-[0] not-italic p-0 relative shrink-0 text-[#272b30] text-left w-full">
              <div className="flex flex-col font-['Lintel:Bold',_sans-serif] h-[17px] justify-center relative shrink-0 text-[16px] w-[133px]">
                <p className="block leading-[21px]">Tipo de contratação</p>
              </div>
              <div className="font-['Lintel:Regular',_sans-serif] min-w-full relative shrink-0 text-[14px]">
                <p className="block leading-[21px]">CBO</p>
              </div>
            </div>
          </div>

          <div className="flex flex-row gap-4">
            <div className="box-border content-stretch flex flex-col gap-2 h-[46px] items-start justify-start leading-[0] not-italic p-0 relative shrink-0 text-[#272b30] text-left">
              <div className="flex flex-col font-['Lintel:Bold',_sans-serif] h-[17px] justify-center relative shrink-0 text-[16px] w-full">
                <p className="block leading-[21px]">Segmento</p>
              </div>
              <div className="font-['Lintel:Regular',_sans-serif] relative shrink-0 text-[14px] w-full">
                <p className="block leading-[21px]">Saúde</p>
              </div>
            </div>
            
            <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start leading-[0] not-italic p-0 relative shrink-0 text-[#272b30] text-left text-nowrap w-[205px]">
              <div className="flex flex-col font-['Lintel:Bold',_sans-serif] justify-center relative shrink-0 text-[16px]">
                <p className="block leading-[21px] text-nowrap whitespace-pre">
                  Constituição da Empresa MEI
                </p>
              </div>
              <div className="font-['Lintel:Regular',_sans-serif] relative shrink-0 text-[14px]">
                <p className="block leading-[21px] text-nowrap whitespace-pre">NÃO</p>
              </div>
            </div>
            
            <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start leading-[0] not-italic p-0 relative shrink-0 text-[#272b30] text-left w-[205px]">
              <div className="flex flex-col font-['Lintel:Bold',_sans-serif] h-[17px] justify-center relative shrink-0 text-[16px] w-full">
                <p className="block leading-[21px]">Vigência de contrato</p>
              </div>
              <div className="font-['Lintel:Regular',_sans-serif] relative shrink-0 text-[14px] w-full">
                <p className="block leading-[21px]">12 meses</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Separator */}
      <div className="h-0 relative shrink-0 w-full">
        <div className="absolute bottom-0 left-0 right-0 top-[-1px]">
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 435 1"
          >
            <line
              stroke="var(--stroke-0, #CED4DA)"
              x2="435"
              y1="0.5"
              y2="0.5"
            />
          </svg>
        </div>
      </div>

      {/* Price and Action */}
      <div className="box-border content-stretch flex flex-col gap-5 items-start justify-start p-0 relative shrink-0 w-full">
        {/* Price */}
        <div className="box-border content-stretch flex flex-col h-[21px] items-start justify-start overflow-clip p-0 relative shrink-0 w-full">
          <div className="font-['Lintel:Bold',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#272b30] text-[0px] text-right w-full">
            <p className="leading-[21px]">
              <span className="font-['Lintel:Bold',_sans-serif] not-italic text-[16px]">
                R$
              </span>
              <span className="text-[21px]"> </span>
              <span className="font-['Lintel:Bold',_sans-serif] not-italic text-[#272b30] text-[26px]">
                2.742,69
              </span>
              <span className="font-['Lintel:Medium',_sans-serif] not-italic text-[16px]">
                /mês
              </span>
            </p>
          </div>
        </div>

        {/* Button and Alert */}
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start overflow-clip p-0 relative shrink-0 w-full">
          <button className="bg-[#f05223] h-8 relative rounded-[100px] shrink-0 w-full hover:bg-[#e04112] transition-colors">
            <div className="flex flex-row justify-center overflow-clip relative size-full">
              <div className="box-border content-stretch flex flex-row gap-2 h-8 items-start justify-center px-2 py-0 relative w-full">
                <div className="box-border content-stretch flex flex-row gap-2 h-8 items-center justify-start p-0 relative shrink-0">
                  <div className="flex flex-col font-['Lintel:Bold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[14px] text-center text-nowrap">
                    <p className="block leading-[18px] whitespace-pre">
                      Gerar proposta comercial
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </button>

          {/* Alert */}
          <div className="box-border content-stretch flex flex-row items-center justify-center p-0 relative shrink-0 w-full">
            <div className="basis-0 bg-[rgba(1,122,173,0.16)] grow h-[120px] min-h-px min-w-px relative rounded-xl shrink-0">
              <div className="absolute left-4 size-5 top-4">
                <Info size={20} color="#017AAD" weight="fill" />
              </div>
              <div className="absolute font-['Roboto:Regular',_sans-serif] font-normal h-[100px] leading-[0] left-11 text-[#017aad] text-[14px] text-left top-4 w-[359px]">
                <p className="block leading-[21px]">
                  Atenção corretor, essa simulação tem validade apenas para hoje, {new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' })} às 18h. Para garantir essa oportunidade, gere a proposta comercial com validade de 45 dias!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function DetalhesDoProductoForm({ onBack, companyName, selectedPlan }: DetalhesDoProductoFormProps) {
  const planData = getPlanData(selectedPlan);

  return (
    <div className="min-h-screen bg-white relative">
      {/* Back button */}
      <div className="absolute left-[360px] top-[76px]">
        <BackButton onClick={onBack} />
      </div>

      {/* Vertical divider */}
      <div className="absolute flex h-[864px] items-center justify-center left-[960px] top-[118px] w-[0px]">
        <div className="flex-none rotate-[270deg]">
          <div className="h-0 relative w-[864px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-1px]">
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 864 1"
              >
                <line
                  stroke="var(--stroke-0, #CED4DA)"
                  x2="864"
                  y1="0.5"
                  y2="0.5"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Plan Details */}
      <PlanDetails
        title={planData.title}
        subtitle={planData.subtitle}
        features={planData.features}
        price={planData.price}
        details={planData.details}
      />

      {/* Cotação Info */}
      <CotacaoInfo companyName={companyName} />
    </div>
  );
}