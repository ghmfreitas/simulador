import { useState, useEffect } from 'react';
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Input } from "./ui/input";
import { Slider } from "./ui/slider";

// Single Value Price Slider Component
interface PriceSliderProps {
  value: number;
  onValueChange: (value: number) => void;
  max: number;
  min: number;
  step: number;
}

function PriceSlider({ value, onValueChange, max, min, step }: PriceSliderProps) {
  return (
    <Slider
      value={[value]}
      onValueChange={(values) => onValueChange(values[0])}
      max={max}
      min={min}
      step={step}
      className="w-full [&_[data-radix-slider-track]]:bg-[#F05223] [&_[data-radix-slider-range]]:bg-[#ced4da] [&_[data-radix-slider-thumb]]:border-[#F05223] [&_[data-radix-slider-thumb]]:bg-white [&_[data-radix-slider-thumb]]:shadow-sm"
    />
  );
}
import { ArrowLeft, Check, Info, Users, SignOut, Trash } from 'phosphor-react';
import svgPaths from "../imports/svg-7elsdmpcx6";
import { Tooltip } from "./ui/tooltip";

interface PlanosSaudeFormProps {
  onBack: () => void;
  onContinue: (data: { selectedPlans?: string[] }) => void;
  onEditLives?: () => void;
  onExitSimulation?: () => void;
  companyName: string;
}

interface Filters {
  maxPrice: number;
  tipoContratacao: {
    cei: boolean;
    compulsoria: boolean;
  };
  vigenciaContratual: {
    doze: boolean;
    vintequatro: boolean;
  };
  coparticipacao: {
    sem: boolean;
    com: boolean;
  };
}

function CheckboxIcon({ checked }: { checked: boolean }) {
  if (checked) {
    return (
      <div className="bg-[#f05223] relative rounded shrink-0 size-6 flex items-center justify-center">
        <Check size={16} color="white" weight="bold" />
      </div>
    );
  }
  
  return (
    <div className="bg-[#ffffff] relative rounded shrink-0 size-6">
      <div className="absolute border border-[#ced4da] border-solid inset-0 pointer-events-none rounded" />
    </div>
  );
}

function BackIcon() {
  return (
    <ArrowLeft 
      size={20} 
      color="#F05223" 
      weight="bold"
    />
  );
}

function BackButton({ onClick }: { onClick: () => void }) {
  return (
    <Button
      onClick={onClick}
      variant="ghost"
      className="inline-flex items-center justify-center h-[48px] px-6 border border-gray-300 text-gray-700 rounded-full hover:bg-gray-50 hover:text-gray-900 transition-colors text-sm gap-2 font-['Aestetico:Medium',_sans-serif]"
    >
      <BackIcon />
      Voltar
    </Button>
  );
}

function CheckIcon() {
  return (
    <div className="relative shrink-0 size-4">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <path
          d={svgPaths.p991aa80}
          fill="var(--fill-0, black)"
        />
      </svg>
    </div>
  );
}



function ActionButton({ 
  onClick, 
  children, 
  icon 
}: { 
  onClick?: () => void; 
  children: React.ReactNode; 
  icon: React.ReactNode; 
}) {
  return (
    <button
      onClick={onClick}
      className="bg-[#ffffff] h-10 relative rounded-[100px] shrink-0 border border-[#f05223] hover:bg-[#fef2f0] transition-colors"
    >
      <div className="box-border content-stretch flex flex-row gap-2 h-10 items-start justify-center overflow-clip px-4 py-0 relative">
        <div className="box-border content-stretch flex flex-row gap-2 h-10 items-center justify-start p-0 relative shrink-0">
          {icon}
          <div className="flex flex-col font-['Lintel:Bold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#f05223] text-[14px] text-center text-nowrap">
            <p className="block leading-[21px] whitespace-pre">{children}</p>
          </div>
        </div>
      </div>
    </button>
  );
}

interface FilterSectionProps {
  title: string;
  children: React.ReactNode;
  tooltip?: string;
}

function FilterSection({ title, children, tooltip }: FilterSectionProps) {
  return (
    <div className="mb-6">
      <div className="flex items-center gap-2 mb-3">
        <h3 className="font-['Aestetico:Bold',_sans-serif] text-[#000000] text-[14px] leading-[21px] font-bold">
          {title}
        </h3>
        {tooltip && (
          <Tooltip content={tooltip} side="right">
            <div className="cursor-help">
              <Info size={16} color="#666666" />
            </div>
          </Tooltip>
        )}
      </div>
      {children}
    </div>
  );
}

interface FilterCheckboxProps {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}

function FilterCheckbox({ label, checked, onChange }: FilterCheckboxProps) {
  return (
    <div className="flex items-center space-x-2 mb-2">
      <div 
        className="cursor-pointer" 
        onClick={() => onChange(!checked)}
      >
        <CheckboxIcon checked={checked} />
      </div>
      <label
        onClick={() => onChange(!checked)}
        className="font-['Aestetico:Regular',_sans-serif] text-[#000000] text-[14px] leading-[21px] cursor-pointer flex-1"
      >
        {label}
      </label>
    </div>
  );
}

interface FilterRadioProps {
  label: string;
  selected: boolean;
  disabled?: boolean;
}

function FilterRadio({ label, selected, disabled = false }: FilterRadioProps) {
  return (
    <div className="flex items-center space-x-2 mb-2">
      <div className={`relative shrink-0 size-6 ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}>
        {selected ? (
          <>
            <div className="absolute bg-[#f05223] inset-0 rounded-full" />
            <div className="absolute bg-[#ffffff] inset-1/4 rounded-full" />
          </>
        ) : (
          <>
            <div className="bg-[#ffffff] relative rounded-full shrink-0 size-6" />
            <div className="absolute border border-[#ced4da] border-solid inset-0 pointer-events-none rounded-full" />
          </>
        )}
      </div>
      <label
        className={`font-['Aestetico:Regular',_sans-serif] text-[#000000] text-[14px] leading-[21px] flex-1 ${
          disabled ? 'cursor-not-allowed' : 'cursor-pointer'
        }`}
      >
        {label}
      </label>
    </div>
  );
}

function FiltersPanel({ filters, onFiltersChange }: { 
  filters: Filters; 
  onFiltersChange: (filters: Filters) => void; 
}) {
  const updateFilters = (section: keyof Filters, key: string, value: any) => {
    const newFilters = { ...filters };
    if (section === 'maxPrice') {
      newFilters[section] = value;
    } else {
      (newFilters[section] as any)[key] = value;
    }
    onFiltersChange(newFilters);
  };

  return (
    <div className="w-[280px] bg-white border-r border-[#e4e4e4] p-6">
      <h2 className="font-['Aestetico:Bold',_sans-serif] text-[#000000] text-[20px] leading-[24px] mb-6 font-bold">
        Filtros
      </h2>

      {/* Faixa de valores */}
      <FilterSection 
        title="Valor máximo" 
        tooltip="Defina o valor máximo que deseja pagar mensalmente pelo plano de saúde"
      >
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <span className="font-['Aestetico:Regular',_sans-serif] text-[#666666] text-[14px] leading-[21px]">
              Até
            </span>
            <span className="font-['Aestetico:Regular',_sans-serif] text-[#000000] text-[14px] leading-[21px]">
              R$ {filters.maxPrice.toLocaleString()}
            </span>
          </div>
          <PriceSlider
            value={filters.maxPrice}
            onValueChange={(value) => updateFilters('maxPrice', '', value)}
            max={9000}
            min={0}
            step={100}
          />
        </div>
      </FilterSection>

      {/* Produto - Saúde PME */}
      <FilterSection 
        title="Produto - Saúde PME" 
        tooltip="Produto de saúde específico para pequenas e médias empresas. Este produto já está pré-selecionado para sua cotação"
      >
        <FilterRadio
          label="557 - AHO"
          selected={true}
          disabled={true}
        />
      </FilterSection>

      {/* Tipo de contratação */}
      <FilterSection 
        title="Tipo de contratação" 
        tooltip="Escolha o tipo de contratação: CBO (Classificação Brasileira de Ocupações), Compulsória (obrigatória para todos) ou Flex (flexível)"
      >
        <FilterCheckbox
          label="CBO"
          checked={filters.tipoContratacao.cei}
          onChange={(checked) => updateFilters('tipoContratacao', 'cei', checked)}
        />
        <FilterCheckbox
          label="Compulsória"
          checked={filters.tipoContratacao.compulsoria}
          onChange={(checked) => updateFilters('tipoContratacao', 'compulsoria', checked)}
        />
      </FilterSection>

      {/* Vigência contratual */}
      <FilterSection 
        title="Vigência contratual" 
        tooltip="Período de duração do contrato. Você pode escolher entre 12 meses ou 24 meses de compromisso"
      >
        <FilterCheckbox
          label="12 meses"
          checked={filters.vigenciaContratual.doze}
          onChange={(checked) => updateFilters('vigenciaContratual', 'doze', checked)}
        />
        <FilterCheckbox
          label="24 meses"
          checked={filters.vigenciaContratual.vintequatro}
          onChange={(checked) => updateFilters('vigenciaContratual', 'vintequatro', checked)}
        />
      </FilterSection>

      {/* Coparticipação */}
      <FilterSection 
        title="Coparticipação" 
        tooltip="Escolha se deseja planos com ou sem coparticipa��ão. Com coparticipação você paga uma taxa adicional por uso dos serviços"
      >
        <FilterCheckbox
          label="Sem coparticipação"
          checked={filters.coparticipacao.sem}
          onChange={(checked) => updateFilters('coparticipacao', 'sem', checked)}
        />
        <FilterCheckbox
          label="Com coparticipação"
          checked={filters.coparticipacao.com}
          onChange={(checked) => updateFilters('coparticipacao', 'com', checked)}
        />
      </FilterSection>
    </div>
  );
}

interface PlanCardProps {
  title: string;
  subtitle: string;
  features: string[];
  price: string;
  onDetailsClick: () => void;
  isSelected?: boolean;
}

function PlanCard({ title, subtitle, features, price, onDetailsClick, isSelected = false }: PlanCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  
  return (
    <div className={`bg-[#ffffff] box-border content-stretch flex flex-col gap-10 items-start justify-start px-0 py-6 relative rounded-xl shrink-0 w-[309px] border transition-colors ${
      isSelected ? 'border-[#f05223] hover:border-[#e04112]' : 'border-[#e4e4e4] hover:border-[#d1d5db]'
    }`}>
      {/* Título */}
      <div className="relative shrink-0 w-full">
        <div className="overflow-clip relative size-full">
          <div className="box-border content-stretch flex flex-col gap-1 items-start justify-start px-4 py-0 relative w-full">
            <div className="box-border content-stretch flex flex-row gap-16 items-start justify-start p-0 relative shrink-0 w-full">
              <div className="font-['Lintel:Bold',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#272b30] text-[20px] text-left text-nowrap">
                <p className="block leading-[18px] whitespace-pre font-bold">{title}</p>
              </div>
            </div>
            <div className="font-['Lintel:Medium',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#818181] text-[14px] text-left w-full">
              <p className="block leading-[18px]">{subtitle}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Benefícios */}
      <div className="relative shrink-0 w-full">
        <div className="overflow-clip relative size-full">
          <div className="box-border content-stretch flex flex-col gap-2.5 items-start justify-start px-4 py-0 relative w-full">
            {features.map((feature, index) => (
              <div key={index}>
                <div className="relative rounded-sm shrink-0 w-full">
                  <div className="flex flex-row items-center justify-center relative size-full">
                    <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-1 py-0 relative w-full">
                      <CheckIcon />
                      <div className="basis-0 font-['Lintel:Medium',_sans-serif] grow leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#000000] text-[14px] text-left">
                        <p className="block leading-[18px]">{feature}</p>
                      </div>
                    </div>
                  </div>
                </div>
                {index < features.length - 1 && (
                  <div className="h-0 relative shrink-0 w-full">
                    <div className="absolute bottom-0 left-0 right-0 top-[-1px]">
                      <svg
                        className="block size-full"
                        fill="none"
                        preserveAspectRatio="none"
                        viewBox="0 0 277 1"
                      >
                        <line
                          stroke="#EAEAEA"
                          x2="277"
                          y1="0.5"
                          y2="0.5"
                        />
                      </svg>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Preço e Botão */}
      <div className="box-border content-stretch flex flex-col gap-4 items-start justify-start p-0 relative shrink-0 w-full">
        {/* Preço */}
        <div className="relative shrink-0 w-full">
          <div className="overflow-clip relative size-full">
            <div className="box-border content-stretch flex flex-col items-start justify-start px-4 py-0 relative w-full">
              <div className="flex flex-col font-['Lintel:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#272b30] text-[0px] text-left w-full">
                <p className="leading-[32px]">
                  <span className="text-[16px]">R$</span>
                  <span className="text-[12px]"> </span>
                  <span className="font-['Lintel:Bold',_sans-serif] not-italic text-[26px]">
                    {price}
                  </span>
                  <span className="text-[16px]">/mês</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Botão */}
        <div className="relative shrink-0 w-full">
          <div className="overflow-clip relative size-full">
            <div className="box-border content-stretch flex flex-col items-start justify-start px-4 py-0 relative w-full">
              <button
                onClick={onDetailsClick}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
                className={`h-8 relative rounded-[100px] shrink-0 w-full transition-colors ${
                  isSelected 
                    ? 'bg-[#e04112] hover:bg-[#d63912]' 
                    : 'bg-[#f05223] hover:bg-[#e04112]'
                }`}
              >
                <div className="flex flex-row justify-center overflow-clip relative size-full">
                  <div className="box-border content-stretch flex flex-row gap-2 h-8 items-start justify-center px-2 py-0 relative w-full">
                    <div className="box-border content-stretch flex flex-row gap-2 h-8 items-center justify-start p-0 relative shrink-0">
                      {isSelected && isHovered && (
                        <Trash size={14} color="#ffffff" weight="bold" />
                      )}
                      <div className="flex flex-col font-['Lintel:Bold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[14px] text-center text-nowrap">
                        <p className="block leading-[18px] whitespace-pre">
                          {isSelected ? (isHovered ? 'Remover plano' : 'Plano selecionado') : 'Selecionar plano'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function PlanosSaudeForm({ 
  onBack, 
  onContinue, 
  onEditLives, 
  onExitSimulation, 
  companyName 
}: PlanosSaudeFormProps) {
  const [selectedPlans, setSelectedPlans] = useState<string[]>([]);
  const [bottomBarOffset, setBottomBarOffset] = useState(0);

  // Effect para detectar posição do footer
  useEffect(() => {
    const updateBarPosition = () => {
      const footer = document.querySelector('[data-footer="true"]') || document.querySelector('footer');
      if (!footer) return;

      const footerRect = footer.getBoundingClientRect();
      const windowHeight = window.innerHeight;
      const barHeight = 80; // Altura aproximada da barra

      // Se o footer está visível na viewport (começando a aparecer)
      if (footerRect.top < windowHeight) {
        // Calcular a distância que a barra precisa subir para não sobrepor o footer
        const footerOverlap = windowHeight - footerRect.top;
        setBottomBarOffset(Math.max(0, footerOverlap));
      } else {
        // Footer não está visível, barra fica no bottom: 0
        setBottomBarOffset(0);
      }
    };

    // Executar no carregamento inicial
    updateBarPosition();

    // Adicionar listener de scroll
    window.addEventListener('scroll', updateBarPosition);
    window.addEventListener('resize', updateBarPosition);

    return () => {
      window.removeEventListener('scroll', updateBarPosition);
      window.removeEventListener('resize', updateBarPosition);
    };
  }, []);

  // Handlers padrão para os novos botões
  const handleEditLives = () => {
    if (onEditLives) {
      onEditLives();
    } else {
      alert('Funcionalidade de editar vidas será implementada');
    }
  };

  const handleExitSimulation = () => {
    if (onExitSimulation) {
      onExitSimulation();
    } else {
      if (window.confirm('Deseja realmente sair da simulação?')) {
        window.location.reload();
      }
    }
  };

  const [filters, setFilters] = useState<Filters>({
    maxPrice: 9000,
    tipoContratacao: {
      cei: false,
      compulsoria: false
    },
    vigenciaContratual: {
      doze: false,
      vintequatro: false
    },
    coparticipacao: {
      sem: false,
      com: false
    }
  });

  const plans = [
    {
      id: 'direto-nacional-enfermaria',
      title: 'Direto Nacional - SP (CA1)',
      subtitle: 'Enfermaria',
      features: ['553 - CBO - 12 meses', 'Sem coparticipação'],
      price: '2.742,69'
    },
    {
      id: 'direto-nacional-apartamento',
      title: 'Direto Nacional - SP (CA1)',
      subtitle: 'Apartamento',
      features: ['553 - CBO - 12 meses', 'Sem coparticipação'],
      price: '3.742,69'
    },
    {
      id: 'classico-vital',
      title: 'Clássico Vital - SP (CA1)',
      subtitle: 'Enfermaria',
      features: ['553 - CBO - 12 meses', 'Sem coparticipação'],
      price: '4.742,69'
    },
    {
      id: 'classico-100',
      title: 'Clássico 100 - SP (CA1)',
      subtitle: 'Enfermaria',
      features: ['553 - CBO - 12 meses', 'Sem coparticipação'],
      price: '5.742,69'
    },
    {
      id: 'especial-100',
      title: 'Especial 100 R1 - SP (CA1)',
      subtitle: 'Apartamento',
      features: ['553 - CBO - 12 meses', 'Sem coparticipação'],
      price: '6.742,69'
    },
    {
      id: 'especial-vital',
      title: 'Especial Vital R1 - SP (CA1)',
      subtitle: 'Apartamento',
      features: ['553 - CBO - 12 meses', 'Sem coparticipação'],
      price: '7.742,69'
    },
    {
      id: 'direto-nacional-compulsoria-enfermaria',
      title: 'Direto Nacional - SP (CA1)',
      subtitle: 'Enfermaria',
      features: ['557 - Compulsória - 12 meses', 'Sem coparticipação'],
      price: '2.852,69'
    },
    {
      id: 'direto-nacional-compulsoria-apartamento',
      title: 'Direto Nacional - SP (CA1)',
      subtitle: 'Apartamento',
      features: ['557 - Compulsória - 12 meses', 'Sem coparticipação'],
      price: '3.862,69'
    }
  ];

  const handlePlanDetails = (planId: string) => {
    // Se o plano já está selecionado, remove; senão, adiciona
    if (selectedPlans.includes(planId)) {
      setSelectedPlans(prev => prev.filter(id => id !== planId));
    } else {
      setSelectedPlans(prev => [...prev, planId]);
    }
  };

  const handleContinue = () => {
    onContinue({ selectedPlans: selectedPlans.length > 0 ? selectedPlans : undefined });
  };

  // Filter plans based on filters (simplified for now)
  const filteredPlans = plans.filter(plan => {
    const planPrice = parseFloat(plan.price.replace('.', '').replace(',', '.'));
    
    // Max price filter
    if (planPrice > filters.maxPrice) {
      return false;
    }
    
    // Other filters can be implemented here based on plan properties
    return true;
  });

  return (
    <div className="flex bg-white">
      {/* Filters Panel */}
      <FiltersPanel filters={filters} onFiltersChange={setFilters} />
      
      {/* Main Content */}
      <div className={`flex-1 px-4 pt-[80px] ${selectedPlans.length > 0 ? 'pb-[120px]' : 'pb-20'}`}>
        <div className="max-w-[1400px] mx-auto">
          <Card className="w-full rounded-xl border-0 shadow-none">
            <CardContent className="p-0">
              <div className="box-border content-stretch flex flex-col gap-6 items-start justify-start p-0 relative shrink-0 w-full">
                {/* Header */}
                <div className="box-border content-stretch flex flex-col gap-4 items-start justify-start p-0 relative shrink-0 w-full">
                  <div className="box-border content-stretch flex flex-col gap-3 items-start justify-start p-0 relative shrink-0 w-full">
                    <div className="box-border content-stretch flex flex-row items-center justify-between p-0 relative shrink-0 w-full">
                      <div className="box-border content-stretch flex flex-row items-center justify-start p-0 relative shrink-0">
                        <div className="font-['Aestetico:Bold',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#101213] text-[24px] text-left text-nowrap">
                          <p className="block leading-[27px] whitespace-pre font-bold">Planos Saúde</p>
                        </div>
                      </div>
                      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-end p-0 relative shrink-0">
                        <ActionButton 
                          onClick={handleEditLives}
                          icon={<Users size={16} color="#f05223" weight="fill" />}
                        >
                          Editar vidas
                        </ActionButton>
                        
                        <ActionButton 
                          onClick={handleExitSimulation}
                          icon={<SignOut size={16} color="#f05223" weight="bold" />}
                        >
                          Sair da simulação
                        </ActionButton>
                      </div>
                    </div>
                    <div className="font-['Aestetico:Regular',_sans-serif] text-[#6b7280] text-[14px] leading-[20px]">
                      Simulação para: <span className="font-['Aestetico:Bold',_sans-serif] text-[#272b30]">{companyName}</span>
                    </div>
                  </div>
                </div>

                {/* Results count */}
                <div className="w-full">
                  <p className="font-['Aestetico:Regular',_sans-serif] text-[#666666] text-[14px] leading-[21px]">
                    {filteredPlans.length} planos encontrados
                  </p>
                </div>

                {/* Grid de Planos - Primeira linha */}
                <div className="box-border content-stretch flex flex-row gap-12 items-start justify-start p-0 relative shrink-0 w-full overflow-x-auto">
                  {filteredPlans.slice(0, 4).map((plan) => (
                    <PlanCard
                      key={plan.id}
                      title={plan.title}
                      subtitle={plan.subtitle}
                      features={plan.features}
                      price={plan.price}
                      onDetailsClick={() => handlePlanDetails(plan.id)}
                      isSelected={selectedPlans.includes(plan.id)}
                    />
                  ))}
                </div>

                {/* Grid de Planos - Segunda linha */}
                {filteredPlans.length > 4 && (
                  <div className="box-border content-stretch flex flex-row gap-12 items-start justify-start p-0 relative shrink-0 w-full overflow-x-auto">
                    {filteredPlans.slice(4, 8).map((plan) => (
                      <PlanCard
                        key={plan.id}
                        title={plan.title}
                        subtitle={plan.subtitle}
                        features={plan.features}
                        price={plan.price}
                        onDetailsClick={() => handlePlanDetails(plan.id)}
                        isSelected={selectedPlans.includes(plan.id)}
                      />
                    ))}
                  </div>
                )}

                {/* Paginação */}
                <div className="box-border content-stretch flex flex-row gap-2 items-start justify-center p-0 relative shrink-0 w-full mb-6">
                  <div className="relative shrink-0 size-8 bg-[#ffffff] rounded border border-[#ced4da]">
                    <div className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] left-1/2 size-6 text-[#ced4da] text-[14px] text-center top-1/2 translate-x-[-50%] translate-y-[-50%]">
                      <p className="block leading-[21px]">←</p>
                    </div>
                  </div>
                  <div className="relative shrink-0 size-8 bg-[#ffffff] rounded border border-[#f05223]">
                    <div className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] left-1/2 size-6 text-[#f05223] text-[14px] text-center top-1/2 translate-x-[-50%] translate-y-[-50%]">
                      <p className="block leading-[21px]">1</p>
                    </div>
                  </div>
                  <div className="relative shrink-0 size-8 bg-[#ffffff] rounded border border-[#ced4da]">
                    <div className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] left-1/2 size-6 text-[#4f575e] text-[14px] text-center top-1/2 translate-x-[-50%] translate-y-[-50%]">
                      <p className="block leading-[21px]">2</p>
                    </div>
                  </div>
                  <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#4f575e] text-[14px] text-center w-4">
                    <p className="block leading-[21px]">...</p>
                  </div>
                  <div className="relative shrink-0 size-8 bg-[#ffffff] rounded border border-[#ced4da]">
                    <div className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] left-1/2 size-6 text-[#4f575e] text-[14px] text-center top-1/2 translate-x-[-50%] translate-y-[-50%]">
                      <p className="block leading-[21px]">10</p>
                    </div>
                  </div>
                  <div className="relative shrink-0 size-8 bg-[#ffffff] rounded border border-[#ced4da]">
                    <div className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] left-1/2 size-6 text-[#101213] text-[14px] text-center top-1/2 translate-x-[-50%] translate-y-[-50%]">
                      <p className="block leading-[21px]">→</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Barra fixa que só aparece quando planos estão selecionados */}
      {selectedPlans.length > 0 && (
        <div 
          className="fixed left-0 right-0 bg-white border-t border-[#e4e7ec] shadow-lg z-40"
          style={{ bottom: `${bottomBarOffset}px` }}
        >
          <div className="max-w-[1400px] mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="font-['Aestetico:Bold',_sans-serif] text-[#272b30] text-[18px] leading-[24px]">
                {selectedPlans.length === 1 ? 'Plano selecionado' : `${selectedPlans.length} planos selecionados`}
              </div>
              
              <Button
                onClick={handleContinue}
                variant="primary"
                size="xl"
                className="px-6 text-[16px] leading-[24px] rounded-full transition-all duration-300 ease-in-out"
              >
                Continuar
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}